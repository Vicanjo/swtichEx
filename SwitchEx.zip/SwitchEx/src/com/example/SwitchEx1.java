/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example;
import java.util.Scanner;
/**
 *
 * @author anshenoy
 */
public class SwitchEx1 {

    public static void main(String args[]) {
        Scanner sn = new Scanner(System.in);
        System.out.println("Introdusca su mes de nacimiento como número");
        int month = sn.nextInt();
        
        switch(month){
            case 1:
                System.out.println("Su mes es enero");
                break;
            case 2:
                System.out.println("Su mes es febrero");
                break;
            case 3:
                System.out.println("Su mes es marzo"); 
                break;
            case 4:
                System.out.println("Su mes es abril");
                break;
            case 5:
                System.out.println("Su mes es mayo");
                break;
            case 6:
                System.out.println("Su mes es junio");
                break;
            case 7:
                System.out.println("Su mes es julio");
                break;
            case 8:
                System.out.println("Su mes es agosto");
                break;
            case 9:
                System.out.println("Su mes es septiembre");
                break;
            case 10:
                System.out.println("Su mes es octubre");
                break;
            case 11:
                System.out.println("Su mes es noviembre");
                break;
            case 12:
                System.out.println("Su mes es diciembre");
                break;
            default:
                System.out.println("Ese mes no existe");
                break;
        }
    }
}
